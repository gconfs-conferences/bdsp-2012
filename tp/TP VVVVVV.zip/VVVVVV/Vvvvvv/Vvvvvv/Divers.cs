﻿using System;
using Microsoft.Xna.Framework;
namespace VVVVVV
{
    static class Divers
    {   // rectangle affiché
        static public int Largeur_Ecran = 512;
        static public int Hauteur_Ecran = 512;
        static public Vector2 CaseDepart_heros;
    }
}
